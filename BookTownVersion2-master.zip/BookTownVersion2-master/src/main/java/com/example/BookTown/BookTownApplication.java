package com.example.BookTown;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookTownApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookTownApplication.class, args);
	}

}
